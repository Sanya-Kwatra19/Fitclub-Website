const express = require('express');
const path = require('path');
const bcrypt = require('bcrypt');
const mongoose = require('mongoose');
const User = require('./models/user');
const nodemailer = require('nodemailer');

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/fitness', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('Error connecting to MongoDB:', err));

// Initialize Express
const app = express();

// Middleware to parse JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set EJS as the view engine
app.set('view engine', 'ejs');

// Serve static files
app.use(express.static(path.join(__dirname, 'public'))); // Ensure correct path

// Route to render the Hero.ejs as the main page
app.get('/', (req, res) => {
    res.render('Hero', {
        hero_image: '/images/hero_image.png',
        Heart: '/images/heart.png',
        Calories: '/images/calories.png'
    });
});

// Route to render the Plans.ejs page
app.get('/Plans', (req, res) => {
    res.render('Plans');
});

// Route to render the Reasons.ejs page
app.get('/reasons', (req, res) => {
    res.render('Reasons');
});

// Route to render the BMI calculator page
app.get('/bmi', (req, res) => {
    res.render('Bmicalculator', {
        bmi: '',
        message: ''
    });
});

// Route to handle BMI calculation
app.post('/bmi', (req, res) => {
    const weight = parseFloat(req.body.weight);
    const height = parseFloat(req.body.height);
    let bmi = '';
    let message = '';

    if (isNaN(weight) || isNaN(height) || weight <= 0 || height <= 0) {
        message = 'Please enter valid weight and height.';
    } else {
        bmi = (weight / (height * height)).toFixed(2);
        if (bmi < 25) {
            message = 'You are underweight';
        } else if (bmi >= 25 && bmi < 30) {
            message = 'You have a healthy body';
        } else {
            message = 'You are overweight';
        }
    }

    res.render('Bmicalculator', {
        bmi: bmi,
        message: message
    });
});

// Route to render the signup page
app.get('/signup', (req, res) => {
    res.render('signup');
});

// Route to handle user signup
app.post('/signup', async (req, res) => {
    const { username, password, email, bmi } = req.body;

    try {
        const usernameLower = username.toLowerCase();
        const existingUser = await User.findOne({ name: usernameLower });

        if (existingUser) {
            return res.send("User already exists. Please choose a different username.");
        }

        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const newUser = new User({
            name: usernameLower,
            email: email,
            password: hashedPassword,
            bmi: bmi
        });

        await newUser.save();
        console.log("User data inserted successfully");
        res.redirect('/login');
    } catch (err) {
        console.error(err);
        res.status(500).send("Error occurred during signup.");
    }
});

// Route to render the login page
app.get('/login', (req, res) => {
    res.render('login');
});

// Route to handle user login
app.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const usernameLower = username.toLowerCase();
        const user = await User.findOne({ name: usernameLower });

        if (!user) {
            return res.send("Username not found.");
        }

        const isPasswordMatch = await bcrypt.compare(password, user.password);
        if (isPasswordMatch) {
            res.render('home'); // Render home page on successful login
        } else {
            res.send("Wrong password.");
        }
    } catch (err) {
        console.error(err);
        res.status(500).send("An error occurred during login.");
    }
});

// Route to handle user logout
app.get('/logout', (req, res) => {
    res.redirect('/');
});

// Route to render the contact page
app.get('/contact', (req, res) => {
    res.render('contact'); // Ensure you have a 'contact.ejs' file in your views directory
});

// Route to handle email sending
app.post('/send-email', async (req, res) => {
    const { userEmail } = req.body;

    // Create a transporter object using SMTP transport
    const transporter = nodemailer.createTransport({
        service: 'gmail', // Use the appropriate email service provider
        auth: {
            user: 'sanyakwatra4@gmail.com', // Your email address
            pass: 'sanya1298@'   // Your email password or an app-specific password
        }
    });

    // Email options
    const mailOptions = {
        from: 'sanyakwatra4@gmail.com',
        to: userEmail,
        subject: 'Thank you for contacting us',
        text: 'We have received your email and will get back to you shortly.'
    };

    try {
        // Send email
        await transporter.sendMail(mailOptions);
        res.send('Email sent successfully.');
    } catch (error) {
        console.error('Error sending email:', error);
        res.status(500).send('Email sent successfully');
    }
});


// Start the server
app.listen(3000, () => {
    console.log("Server listening on port 3000");
});
